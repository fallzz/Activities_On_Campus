#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define pageTableSize 256
#define TLBEntryNum 16
#define frameEntryCount 256
#define frameSize 256
#define offsetMask 255

FILE* address;
FILE* store;
FILE* result;

typedef struct TranslationLookasideBuffer{
    int pageNum[TLBEntryNum];
    int frameNum[TLBEntryNum];
    int tlbCount;
}TranslationLookasideBuffer;

typedef struct pageTableArray{
    int pageNum[pageTableSize];
    int frameNum[pageTableSize];
    int count;
}pageTableArray;

TranslationLookasideBuffer TLB;

pageTableArray pageTable;
int physicalMemory[frameEntryCount][frameSize];
int frameCount;

int logicalAddress;
int pageNum;
int offset;

int accessCount;
int TLBhit;
int pageFault;

int fileOpen();
void tableInit();
int TLBcheck(int logicalAddress);
int pagetableCheck();
int storeRead();
void insertTLB_FIFO();
void insertTLB_LRU();

int main(int argc,char* argv[]){
    if (argc != 2) {
        fprintf(stderr,"Usage: .%s [management number]\n  1.FIFO 2.LRU\n",argv[0]);
        return -1;
    }

    if(fileOpen()) return -1;
    
    int frameNum;
    int mode;
    int check;
    char buffer[10];

    if(!strcmp(argv[1],"1"))      mode=1;
    else if(!strcmp(argv[1],"2")) mode=2;
    else {
        fprintf(stderr,"Usage: .%s [management number]\n  1.FIFO 2.LRU\n",argv[0]);
        return -1;
    }

    tableInit();

    while (fgets(buffer, sizeof(buffer), address) != NULL) {
        logicalAddress = atoi(buffer);
        check=0;
        
        frameNum=TLBcheck(logicalAddress);
        if(frameNum==-1){
            check=-1;
            frameNum=pagetableCheck();
            if(frameNum==-1){
                pageFault++;
                frameNum=storeRead(logicalAddress);
            }
            fprintf(result,"Virtual address: %d Physical address: %d Value: %d\n",
            ((pageNum<<8)+offset),(frameNum<<8)+offset,physicalMemory[frameNum][offset]);

            if(mode==1) insertTLB_FIFO(frameNum);
        }

        if(mode==2) insertTLB_LRU(frameNum,check);
        
        accessCount++; 
    }

    fclose(store);
    fclose(address);

    printf("access Count : %d\n",accessCount);
    if(mode==1) printf("FIFO) TLB hit ratio : %f\nPage fault ratio : %f\n",
    (float)TLBhit/(float)accessCount,(float)pageTable.count/(float)accessCount);
    else printf("LRU) TLB hit ratio : %f\nPage fault ratio : %f\n",
    (float)TLBhit/(float)accessCount,(float)pageTable.count/(float)accessCount);
    return 0;
}

int fileOpen(){
    store = fopen("BACKING_STORE.bin", "rb");
    address = fopen("addresses.txt", "r");
    result = fopen("result.txt", "w");

    if (store == NULL) {
        fprintf(stderr, "BACKING_STORE.bin is not opened.\n");
        return -1;
    }

    if (address == NULL) {
        fprintf(stderr, "address.txt is not opened.\n");
        return -1;
    }

    if (address == NULL) {
        fprintf(stderr, "address.txt is not opened.\n");
        return -1;
    }

    return 0;
}

void tableInit(){
    int i;

    for(i=0; i<pageTableSize; i++){
        pageTable.pageNum[i]=-1;
        pageTable.frameNum[i]=-1;
        pageTable.count=0;
    }

    for(i=0; i<TLBEntryNum; i++){
        TLB.pageNum[i]=-1;
        TLB.frameNum[i]=-1;
        TLB.tlbCount=0;
    }

    return;
}

int TLBcheck(int logicalAddress){
    int i;
    int frameNum=-1;

    pageNum=logicalAddress>>8;
    offset=logicalAddress&offsetMask;

    for(i=0; i<TLBEntryNum; i++){
        if(TLB.pageNum[i]==pageNum){
            frameNum=TLB.frameNum[i];
            TLBhit++;
            break;
        }
    }

    return frameNum;
}

int pagetableCheck(){
    int i;
    int frameNum=-1;
    
    for(i=0; i<=pageTable.count; i++){
        if(pageTable.pageNum[i]==pageNum){
            frameNum=pageTable.frameNum[i];
            break;
        }
    }

    return frameNum;
}

int storeRead(){
    int i;
    char buffer[frameSize];

    fseek(store, pageNum<<8, SEEK_SET) != 0;
    if (fread(buffer, 1, frameSize, store) == 0) {
        fprintf(stderr, "Can not read BACKING_STORE.bin\n");        
    }
    
    for(i = 0; i < frameSize; i++)
        physicalMemory[frameCount][i] = buffer[i];

    pageTable.pageNum[pageTable.count] = pageNum;
    pageTable.frameNum[pageTable.count++] = frameCount;

    return frameCount++;
}

void insertTLB_FIFO(int frameNum){
    TLB.pageNum[TLB.tlbCount]=pageNum;
    TLB.frameNum[TLB.tlbCount++]=frameNum;

    TLB.tlbCount%=TLBEntryNum;

    return;
}

void insertTLB_LRU(int frameNum,int check){
    int i,j;

    if(check==-1){
        for(i=TLBEntryNum-1; i>0; i--){
            TLB.pageNum[i]=TLB.pageNum[i-1];
            TLB.frameNum[i]=TLB.frameNum[i-1];
        }

        TLB.pageNum[0]=pageNum;
        TLB.frameNum[0]=frameNum;
    }
    else{
        for(i=0; i<TLBEntryNum; i++)
            if(TLB.pageNum[i]==pageNum)
                break;

        for(j=i-1; j>0; j--){
            TLB.pageNum[j]=TLB.pageNum[j-1];
            TLB.frameNum[j]=TLB.frameNum[j-1];
        }
        
        TLB.pageNum[0]=pageNum;
        TLB.frameNum[0]=frameNum;
    }
    return;
}