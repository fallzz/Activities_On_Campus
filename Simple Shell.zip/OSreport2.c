#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <wait.h>

#define MAX_TOKENS 128
#define STR_LEN 1024
#define MAX_HISTORY_COUNT 10

struct CMD {	// 명령에 대한 정보를 담는 구조체
	char *name;	// 명령 이름
	int(*cmd)(int argc, char *argv[]);	// 명령 실행 함수에 대한 포인터
};
struct history_type{
	char cmd_str[MAX_HISTORY_COUNT][STR_LEN];
	int rear;
	int num;
	int count;
};

int cmd_processing();
int external_Exe(char* cmdTokens[],int tokenNum,int pipeNo,int pipe_flag);
int cmd_cd(int argc,char* argv[]);
int cmd_pwd(int argc,char* argv[]);
int cmd_exit(int argc,char* argv[]);
int cmd_history(int argc,char* argv[]);
void ign_handler(int signum);
void history_init(void);

struct CMD builtin[] = {	// 내장 명령 정보
	{ "cd", cmd_cd },
	{ "pwd", cmd_pwd },
	{ "exit", cmd_exit },
	{ "history", cmd_history }
};

char* user;
char* session;
static struct sigaction act;
static struct sigaction prev_act;
struct history_type hist;
int sigint_flag;
int exit_flag;
int pipe_flag;
int ipc_pipe[2];
pid_t is_parent;

int main(){
	void ign_handler(int);
	act.sa_handler=ign_handler;
	act.sa_flags=SA_NODEFER;
	sigaction(SIGINT,&act,&prev_act);
	history_init();
	is_parent=getpid();

	if(!(user=getenv("USER"))) perror("getenv: ");
	if(!(session=getenv("SESSION"))) perror("getenv: ");

	while(exit_flag==0){
		sigint_flag=0;
		cmd_processing();
	}

	if(close(ipc_pipe[0])==-1) perror("close:");
	if(close(ipc_pipe[1])==-1) perror("close:");

	return 0;
}

void history_init(){
	hist.rear=0;
	hist.num=0;
	hist.count=0;
}

void ign_handler(int signum){
	printf("\n");
	sigint_flag=1;
	return;
}

int cmd_processing(){
	char cmdLine[STR_LEN];	// 입력 명령 전체를 저장하는 배열
	char *cmdTokens[MAX_TOKENS];	// 입력 명령을 공백으로 분리하여 저장하는 배열
	char delim[] = " \t\n\r";	// 토큰 구분자 - strtok에서 사용
	char *token;	// 하나의 토큰을 분리하는데 사용
	char *pipeTokens[MAX_TOKENS];
	char *pipetoken;
	char path[STR_LEN];
	int tokenNum;	// 입력 명령에 저장된 토큰 수
	int pipe_tokenNum;
	int pipe_flag;
	int is_external;
	pid_t is_child;

	if(!(getcwd(path,STR_LEN)))	perror("getenv: ");
	if(!(is_child=getpid())) perror("getpid: ");

	if(is_child==is_parent){ printf("%s@%s :%s $ ",user,session,path);
		if(fgets(cmdLine,STR_LEN,stdin)!=NULL){
			if(hist.num<MAX_HISTORY_COUNT) hist.num++;
			hist.rear=(hist.rear+1)%MAX_HISTORY_COUNT;
			hist.count++;
			strcpy(hist.cmd_str[hist.rear],cmdLine);
		}
	}
	else read(0,cmdLine,STR_LEN);

	if(sigint_flag==1) return 0;

	pipe_flag=0;
	pipe_tokenNum=0;
	pipetoken=strtok(cmdLine,"|");
	while(pipetoken){
		pipeTokens[pipe_tokenNum++]=pipetoken;
		pipetoken=strtok(NULL,"|");
	}
	if(pipe_tokenNum>1)	{
		pipe_flag=1;
		pipe(ipc_pipe);
	}
	

	for(int i=0; i<pipe_tokenNum; i++){
		is_external=1;
		tokenNum = 0;
		token = strtok(pipeTokens[i], delim);	// 입력 명령의 문자열 하나 분리
		while (token) {	// 문자열이 있을 동안 반복
			cmdTokens[tokenNum++] = token;	// 분리된 문자열을 배열에 저장
			token = strtok(NULL, delim);	// 연속하여 입력 명령의 문자열 하나 분리
		}
		cmdTokens[tokenNum] = NULL;

		if (tokenNum == 0)	return 0;
		for (int j = 0; j < 4; ++j) {		//내장 명령어 검색
		    if (strcmp(cmdTokens[0], builtin[j].name) == 0){
			    if(builtin[j].cmd(tokenNum, cmdTokens)==-1)	perror(cmdTokens[0]);
				is_external=0;
				break;
			}
		}
		if(is_external){
			if((i==(pipe_tokenNum-1))&&pipe_flag) i=MAX_TOKENS;
			external_Exe(cmdTokens,tokenNum,i,pipe_flag);
		}
	}
	return 0;
}

int external_Exe(char* cmdTokens[],int tokenNum,int pipeNo,int pipe_flag){	
	pid_t pid;
	int status;
	
	pid = fork();										//자식 프로세스 생성
	if (pid<0) {										//생성 실패시 에러 처리
		perror("fork: ");
		return -1;
	}
	if (pid == 0) {										//생성된 프로세스가 자식일 때
		sigaction(SIGINT, &prev_act, NULL);
		if(pipe_flag){									//파이프가 있을 때
			if(pipeNo!=MAX_TOKENS){						//마지막으로 수행할 명령어가 아니라면
			if(close(1)==-1) perror("close:");		//표준 출력을 ipc_pipe[1]의 링크로
			if(dup(ipc_pipe[1])==-1) perror("dup");
			}
			if(pipeNo){									//첫 번째로 수행할 명령어가 아니라면
				if(close(0)==-1) perror("close:");		//표준 입력을 ipc_pipe[0]의 링크로
				if(dup(ipc_pipe[0])==-1) perror("dup");
			}
			if(close(ipc_pipe[0])==-1) perror("close:"); //사용하지 않는 파일 디스크립터 닫기
			if(close(ipc_pipe[1])==-1) perror("close:");
		}
		if (execvp(cmdTokens[0], cmdTokens) == -1) {	//단일 명령어 수행
			perror("execvp: ");							//에러 발생 시
			exit(errno);								//자식 프로세스 종료
		}
	}
	else {												//부모 프로세스
		if(pipeNo==MAX_TOKENS){							//***//
			if(close(ipc_pipe[1])==-1) perror("close:");
		}
		if (waitpid(pid, &status, 0) == -1) {			//자식 프로세스 종료까지 대기
			if (status != 0) perror(cmdTokens[0]);		//에러 처리
			if (errno != 0)	printf("%s errno:%d %s\n", cmdTokens[0], errno, strerror(errno));
			return -1;
		}
	}
	return 0;
}

int cmd_cd(int argc, char *argv[]){
	if (argc == 1) {					//인자가 하나일 때
		char* buf;
		buf = getenv("HOME");			//환경변수 HOME의 경로 저장
		if (chdir(buf)) return -1;		//현재 작업 경로 이동
	}
	else if(argc==2)					//인자가 두개일 때
		if (chdir(argv[1])) return -1;	//받은 인자로의 경로 이동
	return 0;
}
int cmd_pwd(int argc, char *argv[]){
	char buf[STR_LEN];
	if (!getcwd(buf, STR_LEN))	return -1; //현재 작업 경로 저장
	else printf("%s\n", buf);			   //출력
	return 0;
}
int cmd_exit(int argc, char *argv[]){
	int status=0;
	sigaction(2, &prev_act, NULL);
	exit(status);						   //종료
	exit_flag=-1;			//종료되지 않았을 시 플래그로 종료
	return 0;
}
int cmd_history(int argc,char *argv[]){
	int i;
	int start=hist.count-hist.num;
	int num;
	int hpipe[2];
	int status;
	pid_t pid;

	if(argc==1){
		for(i=1; i<=hist.num; i++){
			num=start+i;
			printf(" %4d	%s",num,hist.cmd_str[num%MAX_HISTORY_COUNT]);
		}
	}
	/*else if(argc==2){
		if(strcmp(argv[1],"-!!")==0){
			if(strcmp(hist.cmd_str[(hist.rear+8)%MAX_HISTORY_COUNT],"history -!!")){
			write(hpipe[1],hist.cmd_str[(hist.rear+8)%MAX_HISTORY_COUNT],strlen(hist.cmd_str[(hist.rear+9)%MAX_HISTORY_COUNT]));
			pid=fork();
				if(pid==0){
					close(0);
					dup(ipc_pipe[0]);
					if(close(ipc_pipe[0])==-1) perror("close:");
					if(close(ipc_pipe[1])==-1) perror("close:");
					cmd_processing();
					return 0;
				}
			}
			else if(pid>0){
				close(ipc_pipe[1]);
				waitpid(pid,&status,0);
				return 0;
			}
		}
	}*/
	return 0;
}