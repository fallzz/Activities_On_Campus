#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <process.h> 

#define BUF_SIZE 100
#define MAX_CLNT 256

unsigned WINAPI HandleClnt(void * arg);
void ErrorHandling(char * msg);
void visitorList(char *);

void SendMsg(char * msg, int len);
void whispher(char * msg);

int clntCnt = 0;
SOCKET clntSocks[MAX_CLNT];
in_addr clntAddrs[MAX_CLNT];
char clntName[MAX_CLNT][BUF_SIZE];
HANDLE hMutex;

int main(int argc, char *argv[])
{
	WSADATA wsaData;
	SOCKET hServSock, hClntSock;
	SOCKADDR_IN servAdr, clntAdr;
	int clntAdrSz;
	HANDLE  hThread;
	if (argc != 2) {
		printf("Usage : %s <port>\n", argv[0]);
		exit(1);
	}
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
		ErrorHandling("WSAStartup() error!");
	hMutex = CreateMutex(NULL, FALSE, NULL);
	hServSock = socket(PF_INET, SOCK_STREAM, 0);

	memset(&servAdr, 0, sizeof(servAdr));
	servAdr.sin_family = AF_INET;
	servAdr.sin_addr.s_addr = htonl(INADDR_ANY);
	servAdr.sin_port = htons(atoi(argv[1]));

	if (bind(hServSock, (SOCKADDR*)&servAdr, sizeof(servAdr)) == SOCKET_ERROR)
		ErrorHandling("bind() error");
	if (listen(hServSock, 5) == SOCKET_ERROR)
		ErrorHandling("listen() error");

	while (1) {
		clntAdrSz = sizeof(clntAdr);
		hClntSock = accept(hServSock, (SOCKADDR*)&clntAdr, &clntAdrSz);
		char msg[BUF_SIZE];
		WaitForSingleObject(hMutex, INFINITE);
		recv(hClntSock, msg, sizeof(msg), 0);
		strcpy(clntName[clntCnt], strtok(msg, " "));
		clntAddrs[clntCnt] = clntAdr.sin_addr;
		clntSocks[clntCnt++] = hClntSock;
		ReleaseMutex(hMutex);
		hThread = (HANDLE)_beginthreadex(NULL, 0, HandleClnt, (void*)&hClntSock, 0, NULL);
		printf("Connected client IP: %s %s \n", clntName[clntCnt - 1], inet_ntoa(clntAdr.sin_addr));
	}
	closesocket(hServSock);
	WSACleanup();
	return 0;
}

unsigned WINAPI HandleClnt(void * arg){
	SOCKET hClntSock = *((SOCKET*)arg);
	int strLen = 0, i;
	char msg[BUF_SIZE];
	char *buffer;
	char *funcNum;
	char *nickName;

	while ((strLen = recv(hClntSock, msg, sizeof(msg), 0)) != 0) {
		buffer = _strdup(msg);									//�޼��� ����
		nickName = strtok(buffer, " ");							//���� �г��� �и�
		funcNum = strtok(NULL, "\n");							//���ɾ� �и�

		if (!strcmp(funcNum, "/list")) visitorList(nickName);	//������ ��� ��� ���ɾ�
		else if (!strncmp(funcNum, "/to", 3)) whispher(msg);	//�ӼӸ� ��� ���ɾ�
		else SendMsg(msg, strLen);
	}

	WaitForSingleObject(hMutex, INFINITE);
	for (i = 0; i<clntCnt; i++){
		if (hClntSock == clntSocks[i]){
			while (i++<clntCnt - 1)
				clntSocks[i] = clntSocks[i + 1];
			break;
		}
	}
	clntCnt--;
	ReleaseMutex(hMutex);
	closesocket(hClntSock);
	return 0;
}

void visitorList(char *nickName) {
	int i;
	for (i = 0; i < clntCnt; i++)							//��Ͽ��� ��û Client�� ��ġ�ϴ� �г��� �˻�
		if (!strcmp(nickName, clntName[i]))
			break;

	char nickNameList[BUF_SIZE];
	char buffer[BUF_SIZE];

	memset(nickNameList, 0, sizeof(nickNameList));

	WaitForSingleObject(hMutex, INFINITE);
	sprintf(buffer, "���������Connected client���������\n	  Nick		  IP	\n");
	send(clntSocks[i], buffer, strlen(buffer), 0);

	for (int j = 0; j < clntCnt; j++) {						//�������� �г���, IP����Ʈ ��� ���
		sprintf(nickNameList, "	%s		  %s	\n", clntName[j], inet_ntoa(clntAddrs[j]));
		send(clntSocks[i], nickNameList, strlen(nickNameList), 0);
	}

	sprintf(buffer, "�������������������������\n");
	send(clntSocks[i], buffer, strlen(buffer), 0);
	ReleaseMutex(hMutex);
}

void whispher(char * msg) {
	int i, j = -1;
	char *buffer = _strdup(msg);
	char *sender = strtok(buffer, " ");
	char *funcNum = strtok(NULL, " ");
	char *receive_nick = strtok(NULL, " ");
	char *ret = strtok(NULL, "\n");
	char cmpName[BUF_SIZE];

	sprintf(cmpName, "[%s]", receive_nick);
	WaitForSingleObject(hMutex, INFINITE);

	for (i = 0; i < clntCnt; i++) {
		if (!strcmp(clntName[i], cmpName)) {
			j = i;
			send(clntSocks[i], sender, strlen(sender), 0);
			send(clntSocks[i], " ���� �ӼӸ� : ", strlen(" ���� �ӼӸ� : "), 0);
			send(clntSocks[i], ret, strlen(ret), 0);
			send(clntSocks[i], "\n", strlen("\n"), 0);
		}
	}
	if (j == -1) send(clntSocks[i], "  : ", strlen("  "), 0);

	ReleaseMutex(hMutex);
}

void SendMsg(char * msg, int len)
{
	int i;
	WaitForSingleObject(hMutex, INFINITE);
	for (i = 0; i < clntCnt; i++)
		send(clntSocks[i], msg, len, 0);
	ReleaseMutex(hMutex);
}

void ErrorHandling(char * msg)
{
	fputs(msg, stderr);
	fputc('\n', stderr);
	exit(1);
}